#!/bin/bash
more /proc/cpuinfo
