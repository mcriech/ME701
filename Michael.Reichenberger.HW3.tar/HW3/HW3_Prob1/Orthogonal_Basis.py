'''
Created on Oct 13, 2014

@author: michael
'''

class Orth_Basis(object):
    '''
    classdocs
    '''

    def __init__(self):
        '''
        Constructor
        '''
        