'''
Created on Oct 13, 2014

@author: michael
'''
from Orthogonal_Basis import Orth_Basis

class Cont_Orth_Basis(Orth_Basis):
    '''
    classdocs
    '''


    def __init__(self, params):
        '''
        Constructor
        '''
    
    def Transform(self, f):
        '''
        Transforms the funciton f into the form of the continuous orthogonal basis
        '''        
        
        
    def find_weight(self, x):
        '''
        Continuous orthoganol basis requiest a continuous funciton
        '''
        
    def find_P(self, x):
        '''
        Continuous orthoganol basis requires 
        '''